package com.coolevil.chatfilter.mixin;

import com.coolevil.chatfilter.ChatFilterMod;
import com.coolevil.chatfilter.util.TextFilterUtil;
import net.minecraft.client.gui.hud.ChatHud;
import net.minecraft.text.Text;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.ModifyVariable;

/**
 * Intercepts every message before it is stored in the chat history.
 *
 * If the mixin fails to apply, check the exact signature of
 * ChatHud.addMessage() in your Yarn version and add the full descriptor:
 *   method = "addMessage(Lnet/minecraft/text/Text;...)V"
 */
@Mixin(ChatHud.class)
public class ChatHudMixin {

    @ModifyVariable(
        method   = "addMessage",
        at       = @At("HEAD"),
        argsOnly = true,
        ordinal  = 0            // first Text argument
    )
    private Text filterChat(Text message) {
        var cfg = ChatFilterMod.getConfig();
        if (cfg != null && cfg.filterChat) {
            return TextFilterUtil.filterText(message);
        }
        return message;
    }
}
