package com.coolevil.chatfilter.util;

import com.coolevil.chatfilter.ChatFilterMod;
import com.coolevil.chatfilter.filter.FilterEngine;
import net.minecraft.text.Text;

public final class TextFilterUtil {

    private TextFilterUtil() {}

    /**
     * Filter a Minecraft Text component.
     * Returns the original reference unchanged if the filter is off or there
     * is nothing to replace.
     * Style of the root component is preserved; sibling style is flattened
     * (acceptable trade-off for a profanity filter).
     */
    public static Text filterText(Text text) {
        if (text == null) return null;
        ChatFilterMod cfg_holder = null; // accessed via static method below
        if (!isEnabled()) return text;

        String original = text.getString();
        if (original == null || original.isEmpty()) return text;

        String filtered = FilterEngine.getInstance().filter(original);
        if (filtered.equals(original)) return text;

        return Text.literal(filtered).setStyle(text.getStyle());
    }

    /**
     * Filter a plain string (for cases where we don't have a Text object).
     */
    public static String filterString(String str) {
        if (!isEnabled() || str == null || str.isEmpty()) return str;
        return FilterEngine.getInstance().filter(str);
    }

    private static boolean isEnabled() {
        var cfg = ChatFilterMod.getConfig();
        return cfg != null && cfg.enabled;
    }
}
