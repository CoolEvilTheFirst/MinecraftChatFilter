package com.coolevil.chatfilter.mixin;

import com.coolevil.chatfilter.ChatFilterMod;
import com.coolevil.chatfilter.util.TextFilterUtil;
import net.minecraft.entity.boss.BossBar;
import net.minecraft.text.Text;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfoReturnable;

/**
 * Intercepts BossBar.setName() – used by ClientBossBar when the server
 * sends a boss-bar update packet.
 *
 * If the import fails, try:
 *   net.minecraft.world.boss.BossBar
 * (package moved between minor versions).
 */
@Mixin(BossBar.class)
public class BossBarMixin {

    @Inject(method = "getName", at = @At("RETURN"), cancellable = true)
    private void filterBossBarName(CallbackInfoReturnable<Text> cir) {
        var cfg = ChatFilterMod.getConfig();
        if (cfg != null && cfg.filterBossBars) {
            Text name = cir.getReturnValue();
            if (name != null) {
                cir.setReturnValue(TextFilterUtil.filterText(name));
            }
        }
    }
}
