package com.coolevil.chatfilter.mixin;

import com.coolevil.chatfilter.ChatFilterMod;
import com.coolevil.chatfilter.util.TextFilterUtil;
import net.minecraft.client.network.ServerInfo;
import net.minecraft.text.Text;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Redirect;
import net.minecraft.client.gui.screen.multiplayer.MultiplayerServerListWidget;

@Mixin(MultiplayerServerListWidget.ServerEntry.class)
public class ServerEntryMixin {

    @Redirect(
        method = "render",
        at = @At(value = "FIELD", target = "Lnet/minecraft/client/network/ServerInfo;label:Lnet/minecraft/text/Text;", opcode = org.objectweb.asm.Opcodes.GETFIELD)
    )
    private Text filterMotd(ServerInfo serverInfo) {
        Text original = serverInfo.label;
        var cfg = ChatFilterMod.getConfig();
        if (cfg != null && cfg.filterMotds && original != null) {
            return TextFilterUtil.filterText(original);
        }
        return original;
    }
}
