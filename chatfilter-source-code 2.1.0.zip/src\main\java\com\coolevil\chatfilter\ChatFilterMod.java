package com.coolevil.chatfilter;

import net.fabricmc.api.ClientModInitializer;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

public class ChatFilterMod implements ClientModInitializer {

    public static final String MOD_ID = "chatfilter";
    public static final Logger LOGGER = LoggerFactory.getLogger(MOD_ID);

    private static ChatFilterConfig config;

    @Override
    public void onInitializeClient() {
        LOGGER.info("[ChatFilter] Initializing Client...");
        config = ChatFilterConfig.load();
    }

    public static ChatFilterConfig getConfig() {
        return config;
    }
}
