package com.coolevil.chatfilter.mixin;

import com.coolevil.chatfilter.ChatFilterMod;
import com.coolevil.chatfilter.util.TextFilterUtil;
import net.minecraft.client.gui.hud.InGameHud;
import net.minecraft.text.Text;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.ModifyVariable;

/**
 * Covers /title (title + subtitle) and action bar (/title actionbar).
 *
 * If setOverlayMessage doesn't exist in your version, try setActionBar.
 */
@Mixin(InGameHud.class)
public class InGameHudMixin {

    @ModifyVariable(method = "setTitle",    at = @At("HEAD"), argsOnly = true)
    private Text filterTitle(Text title) {
        var cfg = ChatFilterMod.getConfig();
        return (cfg != null && cfg.filterHud) ? TextFilterUtil.filterText(title) : title;
    }

    @ModifyVariable(method = "setSubtitle", at = @At("HEAD"), argsOnly = true)
    private Text filterSubtitle(Text subtitle) {
        var cfg = ChatFilterMod.getConfig();
        return (cfg != null && cfg.filterHud) ? TextFilterUtil.filterText(subtitle) : subtitle;
    }

    // action bar  (ordinal = 0 picks the Text param; second param is boolean tinted)
    @ModifyVariable(method = "setOverlayMessage", at = @At("HEAD"), argsOnly = true, ordinal = 0)
    private Text filterOverlay(Text message) {
        var cfg = ChatFilterMod.getConfig();
        return (cfg != null && cfg.filterHud) ? TextFilterUtil.filterText(message) : message;
    }
}
