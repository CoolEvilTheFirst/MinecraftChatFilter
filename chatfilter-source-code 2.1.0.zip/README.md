# ChatFilter — Fabric 1.21.8

Smart client-side profanity + inappropriate phrase filter.

## What it covers
| Surface | Toggle |
|---|---|
| Chat (incoming) | Filter Chat |
| Signs (front + back) | Filter Signs |
| Player & mob name tags | Filter Name Tags |
| Boss bar titles | Filter Boss Bars |
| Title / Subtitle / Action Bar | Filter HUD |

## How the filter works

**Stage 1 – Word filter**  
Decodes leet speak (`@→a  3→e  1→i  0→o  $→s  ph→f` …), strips symbols,
then checks every word against the bad-word list.  
Also detects spaced-out evasion: `f u c k` → caught.

**Stage 2 – Phrase filter**  
Catches contextually inappropriate combinations where the individual words
alone might be innocent.  Only the bad words inside the phrase are replaced;
the surrounding sentence stays readable.  
Example: `I am not sexually attracted to that woman`  
→ `I am not ######### ######### to that woman`

Bad words are replaced with `#` × (length of the matched word).

---

## Build

### Prerequisites
- JDK 21
- Gradle wrapper scripts (`gradlew` / `gradlew.bat`)  
  Copy these from any Fabric example mod, or run `gradle wrapper` inside the folder.

### Before building — check versions!
Open `gradle.properties` and verify each version against:
- **Yarn / Loader / Fabric API** → https://fabricmc.net/develop/
- **YACL** → https://modrinth.com/mod/yacl  (pick the `1.21.8-fabric` build)
- **ModMenu** → https://modrinth.com/mod/modmenu  (pick the `1.21.8` build)

### Build
```
./gradlew build
```
Grab the jar from `build/libs/chatfilter-1.0.0.jar` and drop it in your mods folder.

---

## Mixin troubleshooting

If the game crashes with a mixin error on startup, the method signature probably
changed in your exact build. Open the failing mixin and add the full descriptor
to the `method = ` field.  For example:

```java
// ChatHudMixin – if there are two addMessage overloads:
@ModifyVariable(
    method   = "addMessage(Lnet/minecraft/text/Text;Lnet/minecraft/client/network/message/MessageSignatureData;Z)V",
    ...
)
```

For **BossBarMixin**, if `net.minecraft.entity.boss.BossBar` doesn't resolve,
try `net.minecraft.world.boss.BossBar` (package varies by version).

For **EntityRendererMixin**, if `renderLabelIfPresent` doesn't resolve,
try `renderLabel` or `renderNameplate`.

For **InGameHudMixin**, if `setOverlayMessage` doesn't resolve, try `setActionBar`.

---

## Adding words / phrases

**Always-censor words** → `BadWordList.java` — add plain strings to the list.

**Contextual phrase rules** → `PhraseList.java` — each rule is:
```java
new PhraseRule(
    "regex pattern on normalised text",
    new int[]{ /* 1-based capture group indices to hashtag */ }
)
```
Groups NOT in the array stay visible.  Groups IN the array are replaced with `#`s.

---

## Config

In-game: open **Mod Menu → ChatFilter → Settings** to toggle each surface.  
Config file: `.minecraft/config/chatfilter.json`
