package com.coolevil.chatfilter.mixin;

import com.coolevil.chatfilter.ChatFilterMod;
import com.coolevil.chatfilter.util.TextFilterUtil;
import net.minecraft.block.entity.SignText;
import net.minecraft.text.Text;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfoReturnable;

/**
 * Filters the Text[] returned by SignText.getMessages(), which is called
 * by the sign block-entity renderer for both front and back faces.
 *
 * The boolean parameter `filtered` indicates whether Mojang's own profanity
 * filter has already been applied (irrelevant here since we use our own).
 */
@Mixin(SignText.class)
public class SignTextMixin {

    @Inject(method = "getMessages", at = @At("RETURN"), cancellable = true)
    private void filterSignLines(boolean filtered, CallbackInfoReturnable<Text[]> cir) {
        var cfg = ChatFilterMod.getConfig();
        if (cfg == null || !cfg.filterSigns) return;

        Text[] messages = cir.getReturnValue();
        Text[] out = new Text[messages.length];
        boolean changed = false;

        for (int i = 0; i < messages.length; i++) {
            Text original = messages[i];
            Text f = TextFilterUtil.filterText(original);
            out[i] = f;
            if (f != original) changed = true;
        }

        if (changed) cir.setReturnValue(out);
    }
}
