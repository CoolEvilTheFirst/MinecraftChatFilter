package com.coolevil.chatfilter.client;

import com.coolevil.chatfilter.ChatFilterMod;
import com.terraformersmc.modmenu.api.ConfigScreenFactory;
import com.terraformersmc.modmenu.api.ModMenuApi;

public class ModMenuIntegration implements ModMenuApi {

    @Override
    public ConfigScreenFactory<?> getModConfigScreenFactory() {
        return parent -> ChatFilterMod.getConfig().buildScreen(parent);
    }
}
