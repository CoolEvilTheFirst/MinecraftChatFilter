package com.coolevil.chatfilter.filter;

import java.util.*;
import java.util.regex.*;

/**
 * Two-stage smart filter:
 *
 *  Stage 1 – Word-level:  every entry in BadWordList is matched against a
 *    normalised form of the input (leet decoded, symbols stripped, spaces
 *    collapsed).  The spaceless ("f u c k") variant is also checked.
 *
 *  Stage 2 – Phrase-level:  PhraseList rules detect contextually inappropriate
 *    phrases and censor only the specific captured words, leaving harmless
 *    surrounding words visible.
 *
 *  All matched spans are merged then applied to the ORIGINAL string in one
 *  pass, so positions are never corrupted.
 */
public final class FilterEngine {

    // ── Singleton ────────────────────────────────────────────────────────────
    private static FilterEngine INSTANCE;
    public static FilterEngine getInstance() {
        if (INSTANCE == null) INSTANCE = new FilterEngine();
        return INSTANCE;
    }

    // ── False-positive whitelist ─────────────────────────────────────────────
    // Full normalised words that must NOT be censored even if a bad-word prefix
    // appears inside them.
    private static final Set<String> WHITELIST = new HashSet<>(Arrays.asList(
        // "ass" false positives
        "assassin","assassinate","assassination",
        "assume","assumption","assuming","assumed","assumes",
        "assist","assistance","assistant","assists","assisted","assisting",
        "associate","association","associates","associated",
        "assemble","assembly","assembling","assembled","assembler",
        "assess","assessment","assessing","assessed",
        "asset","assets",
        "assign","assignment","assigning","assigned","assigns",
        "assert","assertion","asserting","asserted",
        "class","classes","classified","classic","classics","classical",
        "grass","glass","glasses","mass","masses",
        "pass","passes","passage","passenger","passion","passive","password","passing","passed",
        "bass","lass","brass","sass","compass","harass","harassment",
        "embarrass","embarrassment",
        "cassette","casserole","massage","mattress","address","addresses",
        // notable place names
        "scunthorpe","penistone","hitchcock","shitterton",
        // others
        "sit", "sat", "set", "shot", "shut", "suit", "salt", "sort",
        "fact", "fork", "flock", "funk", "flick", "batch", "botch", "butch", "bench", "branch",
        "never", "number", "newer", "nearer", "duck", "deck", "dock", "dark", "dusk", "disk",
        "push", "puss", "pant", "pint", "cant", "cart", "cent", "chat", "coat",
        "where", "whose", "whole", "whale", "white", "slot", "slat", "slit", "slap", "slip", "slop",
        "fat", "fit", "foot", "fort", "font", "fast", "fist", "six", "sect", "shift", "shirt",
        "skirt", "snort", "smart", "start", "spat", "spit", "spot",
        // common false positives from fuzzy matching
        "home", "that", "this", "with", "what", "from", "they", "them", "then", "than", "here", 
        "there", "their", "have", "some", "come", "came", "make", "made", "more", "most", "must", 
        "much", "such", "sure", "time", "take", "took", "give", "gave", "find", "found", "tell", 
        "told", "work", "word", "world", "know", "knew", "good", "well", "best", "better", "look", 
        "like", "love", "hate", "just", "very", "your", "yours", "mine", "ours", "hers", "his", "the",
        "are", "you", "and", "for", "not", "did", "all", "any", "how", "who", "why", "way", "day",
        "out", "now", "see", "say", "too", "man", "men", "boy", "guy", "one", "two", "new", "old",
        "big", "own", "use", "any", "how", "our", "out", "put", "get", "got", "let", "set"
    ));

    // ── Compiled word patterns ────────────────────────────────────────────────
    private final List<Pattern> wordPatterns = new ArrayList<>();

    private FilterEngine() {
        for (String word : BadWordList.WORDS) {
            wordPatterns.add(Pattern.compile(buildSmartRegex(word), Pattern.CASE_INSENSITIVE));
        }
    }

    private String buildSmartRegex(String word) {
        StringBuilder sb = new StringBuilder();
        sb.append("(?i)\\b");
        
        for (int i = 0; i < word.length(); i++) {
            char c = word.charAt(i);
            String leet = getLeetRegex(c);
            
            if (i > 0) {
                // Allow any number of non-alphanumeric characters between letters
                sb.append("[\\W_0-9]*");
            }
            sb.append("[").append(leet).append("]+");
        }
        sb.append("\\b");
        return sb.toString();
    }
    
    private String getLeetRegex(char c) {
        switch(c) {
            case 's': return "s\\$5z";
            case 't': return "t\\+7";
            case 'c': return "c\\(\\<k";
            case 'k': return "kc";
            case 'g': return "g96";
            case 'b': return "b8";
            case 'a': return "a@4";
            case 'e': return "e3";
            case 'i': return "i!1\\|l";
            case 'o': return "o0";
            case 'v': return "vu";
            case 'u': return "uvo0";
            case 'w': return "wv";
            default: return String.valueOf(c);
        }
    }

    private int levenshtein(String a, String b) {
        int[] costs = new int[b.length() + 1];
        for (int j = 0; j < costs.length; j++) costs[j] = j;
        for (int i = 1; i <= a.length(); i++) {
            int nw = costs[0];
            costs[0] = i;
            for (int j = 1; j <= b.length(); j++) {
                int cj = Math.min(1 + Math.min(costs[j], costs[j - 1]),
                        a.charAt(i - 1) == b.charAt(j - 1) ? nw : nw + 1);
                nw = costs[j];
                costs[j] = cj;
            }
        }
        return costs[b.length()];
    }

    // ════════════════════════════════════════════════════════════════════════
    //  Public API
    // ════════════════════════════════════════════════════════════════════════

    /**
     * Filter the input string. Returns the original reference if no changes.
     */
    public String filter(String input) {
        if (input == null || input.isBlank()) return input;

        // ── Collect replacement spans ────
        List<int[]> spans = new ArrayList<>();

        // Stage 1: word-level (smart regex handles leet and noise internally)
        for (Pattern pat : wordPatterns) {
            Matcher m = pat.matcher(input);
            while (m.find()) {
                if (!falsePositive(input, m.start(), m.end())) {
                    spans.add(new int[]{ m.start(), m.end() });
                }
            }
        }

        // Stage 2: Phrase rules
        for (PhraseList.PhraseRule rule : PhraseList.RULES) {
            Matcher m = rule.pattern().matcher(input);
            while (m.find()) {
                spans.add(new int[]{ m.start(), m.end() });
            }
        }

        // Stage 3: Similarity check (Fuzzy matching) on individual words
        // Catches typos and 1-letter substitutions like shkt, fck, bich
        Matcher wordMatcher = Pattern.compile("[a-zA-Z]+").matcher(input);
        while (wordMatcher.find()) {
            String word = wordMatcher.group().toLowerCase();
            if (WHITELIST.contains(word) || word.length() < 3) continue;
            
            for (String bad : BadWordList.WORDS) {
                if (Math.abs(word.length() - bad.length()) > 1) continue;
                if (levenshtein(word, bad) <= 1) {
                    // Check if already covered by regex to avoid duplicate spans (not strictly necessary but cleaner)
                    spans.add(new int[]{ wordMatcher.start(), wordMatcher.end() });
                    break;
                }
            }
        }

        if (spans.isEmpty()) return input;

        // ── Sort & merge overlapping spans ────────────────────────────────
        spans.sort(Comparator.comparingInt(a -> a[0]));
        List<int[]> merged = new ArrayList<>();
        int[] cur = spans.get(0).clone();
        for (int j = 1; j < spans.size(); j++) {
            int[] s = spans.get(j);
            if (s[0] <= cur[1]) cur[1] = Math.max(cur[1], s[1]);
            else { merged.add(cur); cur = s.clone(); }
        }
        merged.add(cur);

        // ── Apply in reverse order ────────────────────────────────────────
        StringBuilder result = new StringBuilder(input);
        for (int j = merged.size() - 1; j >= 0; j--) {
            int[] s = merged.get(j);
            int len = Math.max(s[1] - s[0], 1);
            result.replace(s[0], s[1], "#".repeat(len));
        }
        return result.toString();
    }

    // ── Helpers ───────────────────────────────────────────────────────────────

    /** Returns true if the matched span is part of a whitelisted full word. */
    private boolean falsePositive(String input, int start, int end) {
        String lower = input.toLowerCase();
        int ws = start, we = end;
        while (ws > 0 && Character.isLetterOrDigit(lower.charAt(ws - 1))) ws--;
        while (we < lower.length() && Character.isLetterOrDigit(lower.charAt(we))) we++;
        String word = lower.substring(ws, we).replaceAll("[^a-z0-9]", "");
        return WHITELIST.contains(word);
    }
}
