@echo off
title ChatFilter Mod Builder
echo ========================================
echo   ChatFilter - Fabric 1.21.8 Builder
echo ========================================
echo.

:: Check Java is installed
java -version >nul 2>&1
if errorlevel 1 (
    echo ERROR: Java not found. Install JDK 21 from https://adoptium.net/
    pause
    exit /b 1
)

:: Check gradlew.bat exists
if not exist "gradlew.bat" (
    echo ERROR: gradlew.bat not found.
    echo Run this from inside the chatfilter folder.
    pause
    exit /b 1
)

echo Building mod...
echo.
call gradlew.bat build

if errorlevel 1 (
    echo.
    echo BUILD FAILED. Check the errors above.
    echo Common fix: update version numbers in gradle.properties
    echo See README.md for details.
    pause
    exit /b 1
)

echo.
echo ========================================
echo   BUILD SUCCESSFUL!
echo ========================================
echo.

:: Copy jar to desktop for convenience
set JAR=build\libs\chatfilter-1.0.0.jar
if exist "%JAR%" (
    copy "%JAR%" "%USERPROFILE%\Desktop\chatfilter-1.0.0.jar" >nul
    echo Jar copied to your Desktop!
    echo Drop it into your mods folder and launch Minecraft.
) else (
    echo Jar is in build\libs\
)

echo.
pause
