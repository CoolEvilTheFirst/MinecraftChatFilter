package com.coolevil.chatfilter.mixin;

import com.coolevil.chatfilter.ChatFilterMod;
import com.coolevil.chatfilter.util.TextFilterUtil;
import net.minecraft.entity.Entity;
import net.minecraft.text.Text;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfoReturnable;

@Mixin(Entity.class)
public class EntityMixin {

    @Inject(method = "getName", at = @At("RETURN"), cancellable = true)
    private void filterEntityName(CallbackInfoReturnable<Text> cir) {
        var cfg = ChatFilterMod.getConfig();
        if (cfg != null && cfg.filterNames) {
            Text name = cir.getReturnValue();
            if (name != null) {
                cir.setReturnValue(TextFilterUtil.filterText(name));
            }
        }
    }

    @Inject(method = "getDisplayName", at = @At("RETURN"), cancellable = true)
    private void filterEntityDisplayName(CallbackInfoReturnable<Text> cir) {
        var cfg = ChatFilterMod.getConfig();
        if (cfg != null && cfg.filterNames) {
            Text name = cir.getReturnValue();
            if (name != null) {
                cir.setReturnValue(TextFilterUtil.filterText(name));
            }
        }
    }

    @Inject(method = "getCustomName", at = @At("RETURN"), cancellable = true)
    private void filterEntityCustomName(CallbackInfoReturnable<Text> cir) {
        var cfg = ChatFilterMod.getConfig();
        if (cfg != null && cfg.filterNames) {
            Text name = cir.getReturnValue();
            if (name != null) {
                cir.setReturnValue(TextFilterUtil.filterText(name));
            }
        }
    }
}
