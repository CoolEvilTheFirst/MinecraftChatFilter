package com.coolevil.chatfilter.mixin;

import com.coolevil.chatfilter.ChatFilterMod;
import com.coolevil.chatfilter.filter.FilterEngine;
import net.minecraft.client.gui.screen.SplashTextRenderer;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.ModifyVariable;

@Mixin(SplashTextRenderer.class)
public class SplashTextRendererMixin {

    @ModifyVariable(
        method = "<init>(Ljava/lang/String;)V",
        at = @At("HEAD"),
        argsOnly = true,
        ordinal = 0
    )
    private static String filterSplashText(String text) {
        var cfg = ChatFilterMod.getConfig();
        if (cfg != null && cfg.filterSplash) {
            return FilterEngine.getInstance().filter(text);
        }
        return text;
    }
}
