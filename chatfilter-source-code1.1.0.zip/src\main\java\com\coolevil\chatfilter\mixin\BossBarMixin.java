package com.coolevil.chatfilter.mixin;

import com.coolevil.chatfilter.ChatFilterMod;
import com.coolevil.chatfilter.util.TextFilterUtil;
import net.minecraft.entity.boss.BossBar;
import net.minecraft.text.Text;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.ModifyVariable;

/**
 * Intercepts BossBar.setName() – used by ClientBossBar when the server
 * sends a boss-bar update packet.
 *
 * If the import fails, try:
 *   net.minecraft.world.boss.BossBar
 * (package moved between minor versions).
 */
@Mixin(BossBar.class)
public class BossBarMixin {

    @ModifyVariable(
        method   = "setName",
        at       = @At("HEAD"),
        argsOnly = true
    )
    private Text filterBossBarName(Text name) {
        var cfg = ChatFilterMod.getConfig();
        if (cfg != null && cfg.filterBossBars) {
            return TextFilterUtil.filterText(name);
        }
        return name;
    }
}
