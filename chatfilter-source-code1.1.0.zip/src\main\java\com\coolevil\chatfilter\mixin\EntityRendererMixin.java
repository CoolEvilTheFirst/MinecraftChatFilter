package com.coolevil.chatfilter.mixin;

import com.coolevil.chatfilter.ChatFilterMod;
import com.coolevil.chatfilter.util.TextFilterUtil;
import net.minecraft.client.render.entity.EntityRenderer;
import net.minecraft.text.Text;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.ModifyVariable;

/**
 * Intercepts the text rendered above an entity's head.
 *
 * Covers player name tags, custom-named mob tags, and any entity whose
 * renderer calls renderLabelIfPresent().
 *
 * If the method name changed in your version, check EntityRenderer source
 * (might be renderLabel or renderNameplate).
 */
@Mixin(EntityRenderer.class)
public class EntityRendererMixin {

    @ModifyVariable(
        method   = "renderLabelIfPresent",
        at       = @At("HEAD"),
        argsOnly = true,
        ordinal  = 0    // first Text argument (entity is arg 0 by type, Text is next)
    )
    private Text filterNameTag(Text text) {
        var cfg = ChatFilterMod.getConfig();
        return (cfg != null && cfg.filterNames) ? TextFilterUtil.filterText(text) : text;
    }
}
