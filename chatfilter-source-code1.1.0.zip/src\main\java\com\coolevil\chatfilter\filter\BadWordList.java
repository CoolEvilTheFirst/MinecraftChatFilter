package com.coolevil.chatfilter.filter;

import java.util.List;

/**
 * Words that are ALWAYS censored regardless of context.
 * The FilterEngine normalises leet-speak / symbols before matching,
 * so you only need the plain form here.
 * Patterns are prefix-matched (e.g. "fuck" catches "fucking", "fucker", …).
 *
 * Add or remove freely.
 */
public final class BadWordList {

    private BadWordList() {}

    static final List<String> WORDS = List.of(

        // ── Core profanity ────────────────────────────────────────────────
        "fuck", "fucker", "fucking", "motherfuck", "motherfucker", "motherfucking", "fck",
        "shit", "shitting", "bullshit",
        "ass", "asshole", "arsehole", "arse",
        "bitch", "bitching", "bitches",
        "bastard",
        "piss", "pissing",
        "dick", "dickhead",
        "cock", "cockhead",
        "pussy", "pussies",
        "cunt", "cunts",
        "twat", "twats",
        "prick", "pricks",
        "slut", "sluts",
        "whore", "whores",
        "skank", "skanks",
        "wank", "wanker", "wanking",
        "bollocks",
        "hoe", "hoes",

        // ── Sexual / explicit ─────────────────────────────────────────────
        "porn", "pornography",
        "nude", "nudes", "naked",
        "horny",
        "masturbat",    // prefix catches masturbate / masturbation
        "orgasm", "orgasms",
        "dildo", "dildos",
        "vibrator", "vibrators",
        "blowjob", "blowjobs",
        "handjob", "handjobs",
        "boner", "boners",
        "jizz", "jizzing",
        "cumshot", "cumshots",
        "hentai",
        "onlyfans",
        "sexting",
        "nfsw",
        "nsfw",
        "sex", "sexy",

        // ── Violence / threat ─────────────────────────────────────────────
        "rape", "rapist", "raping",
        "molest", "molester", "molesting",

        // ── Slurs – racial / ethnic ───────────────────────────────────────
        "nigger", "nigga", "niggers", "niggas",
        "chink", "chinks",
        "spic", "spick", "spics",
        "kike", "kikes",
        "gook", "gooks",
        "wetback", "wetbacks",
        "beaner", "beaners",
        "raghead", "towelhead",
        "zipperhead",
        "redskin", "redskins",
        "injun", "injuns",

        // ── Slurs – sexuality / disability ───────────────────────────────
        "faggot", "fag", "faggots", "fags",
        "dyke", "dykes",
        "tranny", "trannies",
        "retard", "retards", "retarded"
    );
}
