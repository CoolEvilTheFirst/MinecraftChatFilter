package com.coolevil.chatfilter.filter;

import java.util.List;
import java.util.regex.Pattern;

/**
 * Contextual phrase rules.
 *
 * These catch inappropriate COMBINATIONS where the individual words alone might
 * be fine.
 *
 * The ENTIRE matching phrase will be censored so that users cannot simply guess
 * what the blocked word was from the remaining context.
 */
public final class PhraseList {

    private PhraseList() {}

    public record PhraseRule(Pattern pattern) {
        PhraseRule(String regex) {
            // Use case insensitive matching for all phrase rules
            this(Pattern.compile(regex, Pattern.CASE_INSENSITIVE));
        }
    }

    public static final List<PhraseRule> RULES = List.of(

        // ── "sexually [adjective/verb]" ───────────────────────────────────
        new PhraseRule("sexually\\s+(?:attracted|attracked|interested|active|explicit|aroused|assaulted|harassed|abused|frustrated|charged|deviant)(?:\\s+to\\s+(?:that|this|a|an|the|my|your|his|her|their)?\\s*(?:woman|man|boy|girl|child|person|kid|animal|dog|cat|horse|pig|sheep))?"),

        // ── "sexual [noun]" ───────────────────────────────────────────────
        new PhraseRule("sexual\\s+(?:harassment|assault|intercourse|content|act|favor|favors|service|services|tension|predator|abuse)"),

        // ── "have / want / get sex" ───────────────────────────────────────
        new PhraseRule("(?:have|had|having|want|wants|wanted|get|got|getting|need|needs|needed|crave|craving)\\s+sex(?:\\s+with(?:\\s+(?:me|you|her|him|them|us|\\w+))?)?"),

        // ── "make love" ───────────────────────────────────────────────────
        new PhraseRule("(?:make|making|made)\\s+love(?:\\s+to(?:\\s+(?:me|you|her|him|them|us|\\w+))?)?"),

        // ── "jerk / jack off" ─────────────────────────────────────────────
        new PhraseRule("(?:jerk|jerking|jack|jacking)\\s+(?:off|it)"),

        // ── "send / ask for nudes" ────────────────────────────────────────
        new PhraseRule("(?:send|sending|sent|share|sharing|shared|ask(?:ing)?\\s+for|want(?:ing)?\\s+to\\s+see)\\s+(?:me\\s+|your\\s+)?(?:nudes?|naked\\s+(?:pics?|photos?|pictures?)|nude\\s+(?:pics?|photos?|pictures?))"),

        // ── "naked / nude [media noun]" ───────────────────────────────────
        new PhraseRule("(?:naked|nude)\\s+(?:pics?|photos?|pictures?|images?|body|selfies?|video)"),

        // ── "sleep / slept with [pronoun]" ────────────────────────────────
        new PhraseRule("(?:sleep(?:ing)?|slept)\\s+with\\s+(?:me|you|her|him|them|us|\\w+)"),

        // ── "strip for / strip down" ──────────────────────────────────────
        new PhraseRule("(?:strip(?:ping)?|undress(?:ing)?)\\s+(?:for|down|off|me|you|us|naked|nude)"),

        // ── "do it with [pronoun]" ────────────────────────────────────────
        new PhraseRule("do\\s+it\\s+with\\s+(?:me|you|her|him|them|us)"),

        // ── "get in(to) [their] pants / underwear" ────────────────────────
        new PhraseRule("(?:get|getting|got)\\s+into?\\s+(?:your|her|his|their|my)\\s+(?:pants|panties?|underwear|shorts|boxers)"),

        // ── "touch / feel / grab [their] privates / crotch" ──────────────
        new PhraseRule("(?:touch(?:ing)?|feel(?:ing)?|grab(?:bing)?)\\s+(?:my|your|her|his|their)\\s+(?:privates?|genitals?|crotch|groin|parts)"),

        // ── "our little secret" (grooming phrase) ────────────────────────
        new PhraseRule("(?:keep\\s+this\\s+)?our\\s+(?:little\\s+secret|secret\\s+between\\s+us)"),

        // ── "being groomed" ──────────────────────────────────────────────
        new PhraseRule("(?:being\\s+)?groomed(?:\\s+by\\s+(?:someone|anyone|\\w+))?"),

        // ── "don't tell [parent/anyone]" (grooming phrase) ───────────────
        new PhraseRule("(?:don'?t\\s+tell|do\\s+not\\s+tell)\\s+(?:anyone|your\\s+(?:parents?|mom|dad|mommy|daddy|guardian|teacher))"),

        // ── Hate speech ───────────────────────────────────────────────────
        new PhraseRule("i\\s+hate\\s+(?:woman|women|man|men|black|white|gay|trans|jews|muslims|christians|asians|hispanics|mexicans|gays|lesbians)"),

        // ── Sexual relations ──────────────────────────────────────────────
        new PhraseRule("i\\s+did\\s+not\\s+have\\s+sexual\\s+relations\\s+with\\s+that\\s+woman"),

        // ── "sex with [animal]" ───────────────────────────────────────────
        new PhraseRule("(?:sex|sexual\\s+act)\\s+with\\s+(?:an?\\s+)?(?:animal|dog|cat|horse|pig|sheep)"),

        // ── "sexy / sexualise [person]" ───────────────────────────────────
        new PhraseRule("(?:sexuali[sz]e|sexualizing|sexualising|sexy)\\s+(?:me|you|her|him|them|us|\\w+)")
    );
}
