import com.coolevil.chatfilter.filter.FilterEngine;

public class TestCurrentLogic {
    public static void main(String[] args) {
        FilterEngine engine = FilterEngine.getInstance();
        System.out.println("Result: " + engine.filter("are"));
        System.out.println("Result: " + engine.filter("are you ok"));
    }
}