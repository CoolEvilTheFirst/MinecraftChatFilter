package com.coolevil.chatfilter;

import com.google.gson.Gson;
import com.google.gson.GsonBuilder;
import dev.isxander.yacl3.api.*;
import dev.isxander.yacl3.api.controller.TickBoxControllerBuilder;
import net.fabricmc.loader.api.FabricLoader;
import net.minecraft.client.gui.screen.Screen;
import net.minecraft.text.Text;

import java.io.IOException;
import java.nio.file.Files;
import java.nio.file.Path;

public class ChatFilterConfig {

    private static final Gson GSON = new GsonBuilder().setPrettyPrinting().create();
    private static final Path CONFIG_PATH =
            FabricLoader.getInstance().getConfigDir().resolve("chatfilter.json");

    // ── toggles ─────────────────────────────────────────────────────────────
    public boolean enabled      = true;
    public boolean filterChat   = true;
    public boolean filterSigns  = true;
    public boolean filterNames  = true;
    public boolean filterBossBars = true;
    public boolean filterHud    = true;   // title / subtitle / action bar
    public boolean filterMotds  = true;   // server list motds

    // ── load / save ─────────────────────────────────────────────────────────
    public static ChatFilterConfig load() {
        if (Files.exists(CONFIG_PATH)) {
            try {
                ChatFilterConfig cfg = GSON.fromJson(Files.readString(CONFIG_PATH), ChatFilterConfig.class);
                if (cfg != null) return cfg;
            } catch (IOException e) {
                ChatFilterMod.LOGGER.error("[ChatFilter] Failed to read config", e);
            }
        }
        ChatFilterConfig fresh = new ChatFilterConfig();
        fresh.save();
        return fresh;
    }

    public void save() {
        try { Files.writeString(CONFIG_PATH, GSON.toJson(this)); }
        catch (IOException e) { ChatFilterMod.LOGGER.error("[ChatFilter] Failed to save config", e); }
    }

    // ── YACL screen ─────────────────────────────────────────────────────────
    public Screen buildScreen(Screen parent) {
        return YetAnotherConfigLib.createBuilder()
                .title(Text.literal("ChatFilter Settings"))
                .category(ConfigCategory.createBuilder()
                        .name(Text.literal("General"))
                        .option(boolOpt("Filter Enabled",
                                "Master on/off switch.",
                                true, () -> enabled, v -> enabled = v))
                        .option(boolOpt("Filter Chat",
                                "Block bad words in incoming chat messages.",
                                true, () -> filterChat, v -> filterChat = v))
                        .option(boolOpt("Filter Signs",
                                "Block bad words on signs.",
                                true, () -> filterSigns, v -> filterSigns = v))
                        .option(boolOpt("Filter Name Tags",
                                "Block bad words in player/mob name tags.",
                                true, () -> filterNames, v -> filterNames = v))
                        .option(boolOpt("Filter Boss Bars",
                                "Block bad words in boss bar titles.",
                                true, () -> filterBossBars, v -> filterBossBars = v))
                        .option(boolOpt("Filter HUD (Title/Action Bar)",
                                "Block bad words in on-screen titles and action bar.",
                                true, () -> filterHud, v -> filterHud = v))
                        .option(boolOpt("Filter MOTDs",
                                "Block bad words in server list MOTDs.",
                                true, () -> filterMotds, v -> filterMotds = v))
                        .build())
                .save(this::save)
                .build()
                .generateScreen(parent);
    }

    private static Option<Boolean> boolOpt(String name, String desc, boolean def,
                                            java.util.function.Supplier<Boolean> get,
                                            java.util.function.Consumer<Boolean> set) {
        return Option.<Boolean>createBuilder()
                .name(Text.literal(name))
                .description(OptionDescription.of(Text.literal(desc)))
                .binding(def, get, set)
                .controller(TickBoxControllerBuilder::create)
                .build();
    }
}
