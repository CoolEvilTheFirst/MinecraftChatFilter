import java.util.regex.*;
import java.util.*;

public class RegexTest {
    public static void main(String[] args) {
        String[] words = {"fuck", "ass", "bitch", "shit", "dick", "nigger"};
        List<Pattern> patterns = new ArrayList<>();
        
        for (String word : words) {
            patterns.add(Pattern.compile(buildSmartRegex(word), Pattern.CASE_INSENSITIVE));
        }
        
        String[] tests = {
            "f@u@c@k", "fock", "f u c k", "fuuuuuck", "grass", "glass", "assassin",
            "b1tch", "b!tch", "b*tch", "b t c h", "sh1t", "sh!t", "sh*t", "s h i t",
            "d1ck", "d!ck", "d*ck", "d i c k", "n1gger", "n!gger", "n*gger", "n i g g e r",
            "f a u c a k", "f a u c k", "fu@ck", "f u@ c k", "fauk", "fck", "f c k", "f.u.c.k", "f_u_c_k"
        };
        
        for (String test : tests) {
            boolean matched = false;
            for (Pattern p : patterns) {
                Matcher m = p.matcher(test);
                if (m.find()) {
                    System.out.println(test + " -> MATCHED: " + p.pattern());
                    matched = true;
                    break;
                }
            }
            if (!matched) {
                System.out.println(test + " -> SAFE");
            }
        }
    }
    
    private static String buildSmartRegex(String word) {
        StringBuilder regex = new StringBuilder();
        regex.append("(?<![a-zA-Z])");
        
        for (int i = 0; i < word.length(); i++) {
            char c = word.charAt(i);
            if ("aeiouy".indexOf(c) >= 0) {
                if (i == 0) {
                    regex.append("[aeiouy4310@!*x]+[\\W_]*");
                } else {
                    regex.append("(?:[aeiouy4310@!*x]+[\\W_]*)*");
                }
            } else {
                String leet = getLeetRegex(c);
                regex.append(leet).append("+[\\W_]*");
            }
        }
        regex.append("(?![a-zA-Z])");
        return regex.toString();
    }
    
    private static String getLeetRegex(char c) {
        switch(c) {
            case 's': return "[s\\$5z]";
            case 't': return "[t\\+7]";
            case 'c': return "[c\\(\\<k]";
            case 'k': return "[kc]";
            case 'g': return "[g96]";
            case 'b': return "[b8]";
            case 'v': return "[vu]";
            case 'u': return "[uv]";
            case 'w': return "(?:w|vv)";
            default: return "[" + c + "]";
        }
    }
}